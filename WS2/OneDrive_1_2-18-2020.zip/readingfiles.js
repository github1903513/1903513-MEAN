var fs = require("fs");
var data = fs.readFileSync("example.txt",callback);
var data = fs.readFileSync("example2.txt",callback);

console.log(data.toString());


function css(response)